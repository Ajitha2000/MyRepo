const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

let player = {
    x: canvas.width / 2,
    y: canvas.height - 30,
    radius: 10,
    color: '#0095DD',
    speed: 5,
    leftPressed: false,
    rightPressed: false
};

let enemies = [];
for (let i = 0; i < 5; i++) {
    enemies.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height / 2,
        radius: 10,
        color: 'red'
    });
}

document.addEventListener('keydown', event => {
    if (event.key === 'ArrowLeft') {
        player.leftPressed = true;
    } else if (event.key === 'ArrowRight') {
        player.rightPressed = true;
    }
});

document.addEventListener('keyup', event => {
    if (event.key === 'ArrowLeft') {
        player.leftPressed = false;
    } else if (event.key === 'ArrowRight') {
        player.rightPressed = false;
    }
});

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.beginPath();
    ctx.arc(player.x, player.y, player.radius, 0, Math.PI * 2);
    ctx.fillStyle = player.color;
    ctx.fill();
    ctx.closePath();

    enemies.forEach(enemy => {
        ctx.beginPath();
        ctx.arc(enemy.x, enemy.y, enemy.radius, 0, Math.PI * 2);
        ctx.fillStyle = enemy.color;
        ctx.fill();
        ctx.closePath();

        let dx = player.x - enemy.x;
        let dy = player.y - enemy.y;
        let distance = Math.sqrt(dx * dx + dy * dy);
        if (distance < player.radius + enemy.radius) {
            alert('Game over!');
            document.location.reload();
        }
    });

    if (player.leftPressed && player.x - player.radius > 0) {
        player.x -= player.speed;
    } else if (player.rightPressed && player.x + player.radius < canvas.width) {
        player.x += player.speed;
    }

    enemies.forEach(enemy => {
        let direction = Math.floor(Math.random() * 2);
        if (direction === 0 && enemy.x - enemy.radius > 0) {
            enemy.x -= 2;
        } else if (direction === 1 && enemy.x + enemy.radius < canvas.width) {
            enemy.x += 2;
        }
    });

    requestAnimationFrame(draw);
}

draw();