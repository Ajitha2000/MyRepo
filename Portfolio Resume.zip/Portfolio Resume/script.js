const scroll = new SmoothScroll('a[href*="#"]', {
    speed: 800
});
const menuButton = document.querySelector('.menu-button');
const navMenu = document.querySelector('.nav-menu');

menuButton.addEventListener('click', () => {
    navMenu.classList.toggle('show');
});
const form = document.querySelector('form');

form.addEventListener('submit', (event) => {
    event.preventDefault();

    const formData = new FormData(form);

    fetch('/submit-form', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (response.ok) {
                return response.json();
            } else {
                throw new Error('Network response was not ok');
            }
        })
        .then(data => {
            const message = document.createElement('p');
            message.textContent = 'Thank you for your submission!';
            form.appendChild(message);
        })
        .catch(error => {
            const message = document.createElement('p');
            message.textContent = 'There was an error submitting your form. Please try again later.';
            form.appendChild(message);
        });
});